import { ArrowUpRight, BarChart3, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import WelcomeScreen from "@/components/WelcomeScreen";
import DataAnalystSection from "@/components/FrontendDeveloperSection";
import Showcase from "./components/Showcase";
import ContactSection from "@/components/ContactSection";
import { Routes, Route } from "react-router-dom";
import About from "./pages/About";

const logos = ["VIJAY", "DATA", "ANALYTICS", "INSIGHTS", "DASHBOARDS", "SQL", "POWER BI"];

export default function App() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [time, setTime] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowWelcome(false), 3200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const updateTime = () => setTime(new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }));
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMobileMenu(false);
  };

  const navItems = [
    ["Home", "home"], ["About", "about"], ["Skills", "showcase"], ["Showcase", "showcase"], ["Contact", "contact"],
  ];

  return (
    <Routes>
      <Route path="/" element={
        <div className="min-h-screen bg-[#050505] text-white overflow-x-hidden">
          <AnimatePresence>{showWelcome && <WelcomeScreen />}</AnimatePresence>

          <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-5 md:px-12 py-5 backdrop-blur-xl bg-black/50 border-b border-white/10">
            <button onClick={() => scrollTo("home")} className="flex items-center gap-3 text-left">
              <img src="/assets/vijay-logo.jpeg" alt="Vijay logo" className="w-10 h-10 rounded-full object-cover border border-white/15" />
              <span className="text-[10px] md:text-xs tracking-[0.28em] text-white/75 uppercase font-semibold">Vijay · Data Analytics</span>
            </button>
            <ul className="hidden lg:flex items-center gap-8 text-[10px] tracking-[0.22em] text-white/65 uppercase">
              {navItems.map(([label, id]) => <li key={id}><button onClick={() => scrollTo(id)} className="hover:text-white transition-colors">{label}</button></li>)}
            </ul>
            <div className="hidden md:block text-[10px] tracking-[0.25em] text-white/55 uppercase">{time}</div>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="lg:hidden text-white">{mobileMenu ? <X size={24} /> : <Menu size={24} />}</button>
          </nav>

          {mobileMenu && <div className="fixed inset-0 z-40 bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center gap-8 uppercase tracking-[0.25em] text-sm lg:hidden">
            {navItems.map(([label, id]) => <button key={id} onClick={() => scrollTo(id)} className="hover:text-white/60">{label}</button>)}
          </div>}

          <section id="home" className="relative min-h-screen flex items-center overflow-hidden px-6 md:px-12 pt-28 pb-16">
            <div className="absolute inset-0 data-grid opacity-40" />
            <div className="absolute -top-48 -right-48 w-[650px] h-[650px] rounded-full bg-white/[0.035] blur-[120px]" />
            <div className="absolute bottom-0 left-0 w-full h-40 bg-gradient-to-t from-[#050505] to-transparent" />
            <div className="relative z-10 w-full max-w-7xl mx-auto grid lg:grid-cols-[1.1fr_.9fr] gap-12 items-center">
              <div>
                <div className="inline-flex items-center gap-2 border border-white/15 bg-white/5 rounded-full px-4 py-2 text-[10px] tracking-[0.25em] uppercase text-white/65 mb-7">
                  <BarChart3 size={14} /> Aspiring Data Analyst
                </div>
                <h1 className="font-display uppercase leading-[0.82] tracking-[-0.04em] text-[18vw] sm:text-[14vw] lg:text-[9rem] xl:text-[11rem]">VIJAY</h1>
                <h2 className="mt-5 text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white/90">Turning Data Into <span className="text-white/45">Insights.</span></h2>
                <p className="mt-7 max-w-xl text-base md:text-lg leading-relaxed text-white/60">I analyze raw data, uncover meaningful patterns, and build clear visual stories that support smarter decisions.</p>
                <div className="mt-9 flex flex-wrap gap-3">
                  {['SQL', 'Python', 'Excel', 'Power BI'].map((item) => <span key={item} className="px-4 py-2 rounded-full border border-white/15 bg-white/[0.04] text-xs tracking-widest text-white/75">{item}</span>)}
                </div>
                <button onClick={() => scrollTo("showcase")} className="mt-10 inline-flex items-center gap-3 border border-white/25 px-6 py-3 rounded-full text-xs tracking-[0.2em] uppercase hover:bg-white hover:text-black transition-all">Explore My Work <ArrowUpRight size={16} /></button>
              </div>
              <div className="relative flex items-center justify-center">
                <div className="absolute w-[75%] aspect-square rounded-full border border-white/10 animate-[spin_20s_linear_infinite]" />
                <div className="absolute w-[58%] aspect-square rounded-full border border-dashed border-white/10" />
                <img src="/assets/vijay-logo.jpeg" alt="Vijay V" className="relative z-10 w-64 md:w-80 rounded-[2rem] object-cover shadow-[0_30px_100px_rgba(255,255,255,0.08)] border border-white/10" />
                <div className="absolute bottom-4 right-0 md:right-8 z-20 bg-black/80 backdrop-blur-xl border border-white/15 rounded-2xl px-5 py-4">
                  <p className="text-[10px] tracking-[0.25em] uppercase text-white/45">Focus</p><p className="mt-1 font-semibold">Data Analytics</p>
                </div>
              </div>
            </div>
          </section>

          <div className="border-y border-white/10 py-5 overflow-hidden bg-black">
            <div className="flex items-center gap-12 animate-marquee whitespace-nowrap">{[...logos, ...logos, ...logos].map((logo, i) => <span key={i} className="text-white/35 text-xs tracking-[0.3em] uppercase">{logo}</span>)}</div>
          </div>
          <style>{`@keyframes marquee {0%{transform:translateX(0)}100%{transform:translateX(-33.333%)}} .animate-marquee{animation:marquee 16s linear infinite}.data-grid{background-image:linear-gradient(rgba(255,255,255,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.06) 1px,transparent 1px);background-size:48px 48px}`}</style>

          <section id="about"><DataAnalystSection /></section>
          <section id="showcase"><Showcase /></section>
          <section id="contact"><ContactSection /></section>
        </div>
      } />
      <Route path="/about" element={<About />} />
    </Routes>
  );
}
