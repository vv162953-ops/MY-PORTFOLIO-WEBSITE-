import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowUpRight, Database, LineChart, Table2 } from "lucide-react";

const skills = ["Microsoft Excel", "SQL", "Power BI", "Python", "Data Analysis", "Data Visualization", "Dashboard Creation", "Database Management"];

export default function DataAnalystSection() {
  const navigate = useNavigate();
  return (
    <section className="relative min-h-screen bg-black text-white overflow-hidden px-6 md:px-20 py-24 md:py-32">
      <div className="absolute inset-0 data-grid opacity-20" />
      <div className="relative z-10 max-w-7xl mx-auto grid lg:grid-cols-[1fr_.85fr] gap-16 items-center">
        <div>
          <p className="text-[10px] tracking-[0.35em] uppercase text-white/45 mb-5">01 — About Me</p>
          <motion.h2 initial={{opacity:0,y:35}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{duration:.7}} className="font-extrabold leading-[.95] tracking-tight text-[clamp(54px,8vw,110px)]">Data<br/><span className="text-white/45">Analyst.</span></motion.h2>
          <p className="mt-8 max-w-2xl text-base md:text-xl leading-relaxed text-white/65">I’m <span className="text-white font-semibold">Vijayakumar V</span>, a B.Tech Information Technology student and aspiring Data Analyst passionate about turning raw data into meaningful insights. I enjoy exploring datasets, identifying trends, and building dashboards that make information easy to understand.</p>
          <p className="mt-5 max-w-2xl text-base md:text-lg leading-relaxed text-white/45">Curious mind. Analytical thinking. Continuous learning. I’m building my skills through hands-on practice in data cleaning, analysis, visualization, and reporting.</p>
          <button onClick={() => navigate('/about')} className="mt-9 inline-flex items-center gap-3 rounded-full border border-white/20 px-6 py-3 text-xs tracking-[0.2em] uppercase hover:bg-white hover:text-black transition-all">View My Profile <ArrowUpRight size={16}/></button>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {[{icon:<Database/>,title:'Analyze',text:'Explore datasets and discover useful patterns.'},{icon:<LineChart/>,title:'Visualize',text:'Turn numbers into clear, interactive stories.'},{icon:<Table2/>,title:'Report',text:'Present insights that support better decisions.'}].map((card,i)=><motion.div key={card.title} initial={{opacity:0,y:30}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.12}} className={`rounded-3xl border border-white/10 bg-white/[.035] p-7 backdrop-blur-xl ${i===2?'sm:col-span-2':''}`}><div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-white/80">{card.icon}</div><h3 className="mt-7 text-2xl font-bold">{card.title}</h3><p className="mt-3 text-sm leading-relaxed text-white/50">{card.text}</p></motion.div>)}</div>
      </div>
      <div className="relative z-10 max-w-7xl mx-auto mt-16 flex flex-wrap gap-3">{skills.map(skill=><span key={skill} className="rounded-full border border-white/10 px-4 py-2 text-xs text-white/60 bg-white/[.025]">{skill}</span>)}</div>
      <style>{`.data-grid{background-image:linear-gradient(rgba(255,255,255,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.06) 1px,transparent 1px);background-size:48px 48px}`}</style>
    </section>
  );
}
