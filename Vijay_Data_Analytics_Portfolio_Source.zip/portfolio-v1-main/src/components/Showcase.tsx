import { BarChart3, Database, FileSpreadsheet, Code2, Award } from "lucide-react";

const tools = [
  { name: "Microsoft Excel", icon: FileSpreadsheet, text: "Data cleaning, formulas, reporting and analysis" },
  { name: "SQL", icon: Database, text: "Querying, filtering and managing structured data" },
  { name: "Power BI", icon: BarChart3, text: "Interactive dashboards and meaningful visualizations" },
  { name: "Python", icon: Code2, text: "Basic data analysis and problem solving" },
];

const strengths = ["Data Cleaning", "Data Analysis", "Data Visualization", "Dashboard Creation", "Database Management", "Reporting"];

export default function Showcase() {
  return (
    <section className="relative bg-[#070707] text-white px-6 md:px-20 py-24 md:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-14">
          <div><p className="text-[10px] tracking-[0.35em] uppercase text-white/45 mb-4">02 — Skills & Showcase</p><h2 className="text-5xl md:text-7xl font-black tracking-tight">Tools I Use.</h2></div>
          <p className="max-w-md text-white/50 leading-relaxed">A focused toolkit for exploring data, building dashboards, and communicating insights clearly.</p>
        </div>
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
          {tools.map(({name,icon:Icon,text},i)=><article key={name} className="group min-h-64 rounded-3xl border border-white/10 bg-gradient-to-b from-white/[.06] to-transparent p-7 hover:border-white/25 transition-all duration-500 hover:-translate-y-1"><div className="w-12 h-12 rounded-2xl border border-white/10 bg-black flex items-center justify-center"><Icon size={22}/></div><p className="mt-10 text-[10px] tracking-[.25em] text-white/40">0{i+1}</p><h3 className="mt-2 text-2xl font-bold">{name}</h3><p className="mt-3 text-sm text-white/50 leading-relaxed">{text}</p></article>)}
        </div>

        <div className="mt-20 grid lg:grid-cols-[1fr_.8fr] gap-6 items-stretch">
          <div className="rounded-[2rem] border border-white/10 bg-white/[.025] p-8 md:p-12">
            <p className="text-[10px] tracking-[.3em] uppercase text-white/40">What I’m building</p>
            <h3 className="mt-5 text-4xl md:text-5xl font-bold leading-tight">From raw numbers to <span className="text-white/45">clear decisions.</span></h3>
            <div className="mt-10 flex flex-wrap gap-3">{strengths.map(item=><span key={item} className="rounded-full px-4 py-2 border border-white/10 text-sm text-white/65">{item}</span>)}</div>
          </div>
          <div className="rounded-[2rem] border border-white/10 bg-black p-8 flex flex-col justify-between"><Award className="text-white/70" size={42}/><div><p className="text-[10px] tracking-[.3em] uppercase text-white/40">Certification</p><h3 className="mt-3 text-2xl font-bold">Deloitte Data Analytics Job Simulation</h3><p className="mt-3 text-white/50 text-sm leading-relaxed">Hands-on exposure to data analytics tasks and real-world problem-solving concepts.</p></div></div>
        </div>
      </div>
    </section>
  );
}
