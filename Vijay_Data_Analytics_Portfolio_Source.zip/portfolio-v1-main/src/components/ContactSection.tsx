import { FaEnvelope, FaGithub, FaLinkedin } from "react-icons/fa";
import { ArrowUpRight } from "lucide-react";

export default function ContactSection() {
  return (
    <section className="relative min-h-[80vh] bg-black text-white px-6 md:px-20 py-24 overflow-hidden flex items-center">
      <div className="absolute inset-0 opacity-[.04]" style={{backgroundImage:'linear-gradient(rgba(255,255,255,.08) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.08) 1px,transparent 1px)',backgroundSize:'48px 48px'}} />
      <div className="relative z-10 max-w-7xl mx-auto w-full grid lg:grid-cols-[1fr_.8fr] gap-14 items-center">
        <div><p className="text-[10px] tracking-[.35em] uppercase text-white/45">03 — Contact</p><h2 className="mt-5 text-5xl md:text-8xl font-black tracking-tight leading-[.9]">Let’s Talk<br/><span className="text-white/40">Data.</span></h2><p className="mt-7 max-w-xl text-white/55 leading-relaxed text-lg">Interested in connecting, collaborating, or discussing data analytics? I’m always open to learning opportunities and meaningful conversations.</p></div>
        <div className="rounded-[2rem] border border-white/10 bg-white/[.035] backdrop-blur-xl p-8 md:p-10"><p className="text-[10px] tracking-[.3em] uppercase text-white/40">Get in touch</p><h3 className="mt-4 text-3xl font-bold">Vijayakumar V</h3><p className="mt-2 text-white/45">Aspiring Data Analyst</p><a href="mailto:vv162953@gmail.com" className="mt-9 flex items-center justify-between rounded-2xl border border-white/10 p-5 hover:bg-white hover:text-black transition-all"><span className="flex items-center gap-3"><FaEnvelope/> vv162953@gmail.com</span><ArrowUpRight size={18}/></a><div className="mt-5 flex gap-3"><a href="#" aria-label="LinkedIn" className="w-12 h-12 rounded-xl border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all"><FaLinkedin size={20}/></a><a href="#" aria-label="GitHub" className="w-12 h-12 rounded-xl border border-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-all"><FaGithub size={20}/></a></div></div>
      </div>
      <p className="absolute bottom-7 left-0 right-0 text-center text-xs tracking-[.18em] text-white/30">© {new Date().getFullYear()} VIJAYAKUMAR V · DATA ANALYTICS</p>
    </section>
  );
}
