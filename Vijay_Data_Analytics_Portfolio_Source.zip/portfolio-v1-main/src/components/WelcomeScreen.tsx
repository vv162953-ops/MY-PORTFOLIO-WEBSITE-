import { motion } from "framer-motion";
import { BarChart3, Database, LineChart, Table2 } from "lucide-react";

export default function WelcomeScreen() {
  const icons = [Database, BarChart3, LineChart, Table2];
  return <motion.div initial={{opacity:1}} exit={{opacity:0}} transition={{duration:.6}} className="fixed inset-0 z-[100] bg-black text-white flex items-center justify-center overflow-hidden">
    <div className="absolute inset-0 opacity-30" style={{backgroundImage:'radial-gradient(circle at center, rgba(255,255,255,.12), transparent 45%)'}} />
    <motion.div initial={{opacity:0,y:20}} animate={{opacity:1,y:0}} className="relative z-10 text-center px-6">
      <div className="flex justify-center gap-4 mb-8">{icons.map((Icon,i)=><motion.div key={i} initial={{opacity:0,scale:.5}} animate={{opacity:1,scale:1}} transition={{delay:i*.1}} className="w-11 h-11 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center"><Icon size={19}/></motion.div>)}</div>
      <img src="/assets/vijay-wordmark.png" alt="VIJAY" className="w-64 md:w-80 mx-auto mix-blend-screen" />
      <p className="mt-7 text-xs md:text-sm tracking-[.28em] uppercase text-white/55">Data Analytics Portfolio</p>
      <div className="mt-8 w-56 h-px bg-white/15 overflow-hidden mx-auto"><motion.div initial={{width:'0%'}} animate={{width:'100%'}} transition={{duration:2.7,ease:'easeInOut'}} className="h-full bg-white" /></div>
    </motion.div>
  </motion.div>;
}
